//
//  Color+Ext.swift
//  yasee_ios_demo
//
//  Created by Henry Gao on 2024/8/15.
//

import SwiftUI

extension Color {
    static var random: Color {
        return Color(
            red: .random(in: 0...1),
            green: .random(in: 0...1),
            blue: .random(in: 0...1)
        )
    }
}
